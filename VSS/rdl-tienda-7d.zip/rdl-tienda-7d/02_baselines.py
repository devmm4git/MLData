"""
Paso 2 · Baselines para customer-buy-7d (misma etiqueta que usará RDL).

  A. Regla "lo que pasó la semana pasada": score = pedidos en los 7 días previos al corte.
  B. Regla de recencia: score = -(días desde el último pedido).
  C. LightGBM con features básicas (cliente + pedidos).
  D. LightGBM con features relacionales (+ vistas, envíos, devoluciones, reseñas).

Todas las features usan solo filas con fecha <= t (el corte) -> sin fuga.
Guarda métricas en resultados/baselines.json.

    python 02_baselines.py ../rel-tienda
"""
import json
import sys
import time
from pathlib import Path

import duckdb
import lightgbm as lgb
import numpy as np
import pandas as pd
from relbench.load import load_dataset

ROOT = sys.argv[1] if len(sys.argv) > 1 else "rel-tienda"
OUT = Path("resultados"); OUT.mkdir(exist_ok=True)
TASK = "customer-buy-7d"

ds = load_dataset(ROOT)
task = ds.load_task(TASK)
db = task.get_db(upto_test_timestamp=False)
splits = {s: task.get_table(s, mask_input_cols=False).df for s in ["train", "val", "test"]}

FEATURES_SQL = """
WITH o AS (
  SELECT L.timestamp, L.customer_id, o.order_date,
         SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct)) AS monto,
         SUM(oi.quantity) AS piezas
  FROM L JOIN orders o ON o.customer_id = L.customer_id AND o.order_date <= L.timestamp
  JOIN order_item oi ON oi.order_id = o.order_id
  GROUP BY L.timestamp, L.customer_id, o.order_id, o.order_date
), fo AS (
  SELECT timestamp, customer_id,
    COUNT(*) FILTER (WHERE order_date > timestamp - INTERVAL 7 DAY)  AS ped_7,
    COUNT(*) FILTER (WHERE order_date > timestamp - INTERVAL 14 DAY) AS ped_14,
    COUNT(*) FILTER (WHERE order_date > timestamp - INTERVAL 30 DAY) AS ped_30,
    COUNT(*) FILTER (WHERE order_date > timestamp - INTERVAL 90 DAY) AS ped_90,
    COUNT(*) AS ped_total,
    date_diff('hour', MAX(order_date), timestamp) / 24.0 AS recencia_dias,
    SUM(monto) FILTER (WHERE order_date > timestamp - INTERVAL 90 DAY) AS gasto_90,
    SUM(monto) AS gasto_total,
    AVG(piezas) AS piezas_prom,
    -- intervalo promedio entre pedidos (ritmo del cliente)
    date_diff('hour', MIN(order_date), MAX(order_date)) / 24.0 / GREATEST(COUNT(*) - 1, 1) AS dias_entre_pedidos
  FROM o GROUP BY timestamp, customer_id
), fv AS (
  SELECT L.timestamp, L.customer_id,
    COUNT(*) FILTER (WHERE v.view_time > L.timestamp - INTERVAL 7 DAY)  AS vistas_7,
    COUNT(*) FILTER (WHERE v.view_time > L.timestamp - INTERVAL 30 DAY) AS vistas_30,
    COUNT(*) FILTER (WHERE v.added_to_cart AND v.view_time > L.timestamp - INTERVAL 7 DAY) AS carrito_7,
    date_diff('hour', MAX(v.view_time), L.timestamp) / 24.0 AS dias_ultima_vista
  FROM L JOIN view v ON v.customer_id = L.customer_id AND v.view_time <= L.timestamp
                     AND v.view_time > L.timestamp - INTERVAL 30 DAY
  GROUP BY L.timestamp, L.customer_id
), fs AS (
  SELECT L.timestamp, L.customer_id,
    AVG(s.delay_days) AS retraso_prom_90,
    SUM((s.delay_days > 1)::INT) AS envios_tarde_90
  FROM L JOIN orders o ON o.customer_id = L.customer_id
         JOIN shipment s ON s.order_id = o.order_id AND s.delivered_at <= L.timestamp
                        AND s.delivered_at > L.timestamp - INTERVAL 90 DAY
  GROUP BY L.timestamp, L.customer_id
), fr AS (
  SELECT L.timestamp, L.customer_id, COUNT(*) AS devoluciones_90
  FROM L JOIN orders o ON o.customer_id = L.customer_id
         JOIN order_item oi ON oi.order_id = o.order_id
         JOIN product_return r ON r.order_item_id = oi.order_item_id AND r.return_date <= L.timestamp
                              AND r.return_date > L.timestamp - INTERVAL 90 DAY
  GROUP BY L.timestamp, L.customer_id
), fw AS (
  SELECT L.timestamp, L.customer_id, AVG(rv.rating) AS rating_dado_prom,
         SUM((rv.rating <= 2)::INT) AS malas_resenas
  FROM L JOIN review rv ON rv.customer_id = L.customer_id AND rv.review_date <= L.timestamp
  GROUP BY L.timestamp, L.customer_id
)
SELECT L.timestamp, L.customer_id,
  c.is_premium::INT AS is_premium, c.age_group, c.acquisition_channel, c.state,
  date_diff('day', c.signup_date, L.timestamp) AS dias_alta,
  fo.* EXCLUDE (timestamp, customer_id),
  fv.* EXCLUDE (timestamp, customer_id),
  fs.* EXCLUDE (timestamp, customer_id),
  fr.* EXCLUDE (timestamp, customer_id),
  fw.* EXCLUDE (timestamp, customer_id)
FROM L JOIN customer c USING (customer_id)
LEFT JOIN fo USING (timestamp, customer_id)
LEFT JOIN fv USING (timestamp, customer_id)
LEFT JOIN fs USING (timestamp, customer_id)
LEFT JOIN fr USING (timestamp, customer_id)
LEFT JOIN fw USING (timestamp, customer_id)
"""
BASICAS = ["is_premium", "age_group", "acquisition_channel", "state", "dias_alta", "ped_7", "ped_14",
           "ped_30", "ped_90", "ped_total", "recencia_dias", "gasto_90", "gasto_total", "piezas_prom",
           "dias_entre_pedidos"]
RELACIONALES = BASICAS + ["vistas_7", "vistas_30", "carrito_7", "dias_ultima_vista", "retraso_prom_90",
                          "envios_tarde_90", "devoluciones_90", "rating_dado_prom", "malas_resenas"]
CNT = ["vistas_7", "vistas_30", "carrito_7", "envios_tarde_90", "devoluciones_90", "malas_resenas"]


def features(L):
    con = duckdb.connect()
    for name, t in db.table_dict.items():
        con.register(name, t.df)
    con.register("L", L[["timestamp", "customer_id"]])
    f = con.sql(FEATURES_SQL).df()
    con.close()
    f[CNT] = f[CNT].fillna(0)
    return L.merge(f, on=["timestamp", "customer_id"], how="left")


t0 = time.time()
X = {s: features(df) for s, df in splits.items()}
print(f"features listas en {time.time() - t0:.0f}s")


def auroc(split, score):
    return task.evaluate(np.asarray(score, float), task.get_table(split, mask_input_cols=False))["roc_auc"]


res = {}
# ---------------- A / B: reglas ----------------
for s in ["val", "test"]:
    res.setdefault("A · regla: compró la semana pasada", {})[s] = auroc(s, X[s]["ped_7"])
    res.setdefault("B · regla: recencia", {})[s] = auroc(s, -X[s]["recencia_dias"])

# ---------------- C / D: LightGBM ----------------
cats = ["age_group", "acquisition_channel", "state"]


def prep(df, cols):
    d = df[cols].copy()
    for c in cats:
        if c in d:
            d[c] = pd.Categorical(d[c], categories=sorted(X["train"][c].unique()))
    return d


importancias = {}
for name, cols in [("C · LightGBM features básicas", BASICAS), ("D · LightGBM + features relacionales", RELACIONALES)]:
    m = lgb.LGBMClassifier(n_estimators=3000, learning_rate=0.03, num_leaves=63, min_child_samples=50,
                           subsample=0.8, subsample_freq=1, colsample_bytree=0.8, verbose=-1)
    m.fit(prep(X["train"], cols), X["train"]["compra_7d"],
          eval_set=[(prep(X["val"], cols), X["val"]["compra_7d"])], eval_metric="auc",
          callbacks=[lgb.early_stopping(150, verbose=False)])
    res[name] = {s: auroc(s, m.predict_proba(prep(X[s], cols))[:, 1]) for s in ["val", "test"]}
    imp = pd.Series(m.booster_.feature_importance("gain"), index=cols)
    importancias[name] = (imp / imp.sum()).sort_values(ascending=False).head(8).round(3).to_dict()

print(f"\n{'modelo':42s} {'AUROC val':>10s} {'AUROC test':>11s}")
for k, v in res.items():
    print(f"{k:42s} {v['val']:10.4f} {v['test']:11.4f}")
print("\nImportancia (gain) LightGBM relacional:", importancias["D · LightGBM + features relacionales"])
json.dump({"resultados": res, "importancias": importancias}, open(OUT / "baselines.json", "w"), indent=2,
          ensure_ascii=False)
