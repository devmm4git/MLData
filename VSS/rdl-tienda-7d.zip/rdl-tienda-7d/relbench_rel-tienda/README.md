# rel-tienda — marketplace e-commerce sintético para Relational Deep Learning

Base de datos relacional sintética al estilo de `rel-amazon`, `rel-hm` y `rel-avito` de RelBench.
Simula un marketplace mexicano de ene-2024 a jun-2026: clientes, vendedores, productos,
pedidos, envíos, reseñas, devoluciones y navegación.

Formato **BYOD de RelBench** (`manifest.yaml` + `db/*.parquet` + `tasks/<tarea>/`).
Valida con `python -m relbench.validate rel-tienda` → 0 errores.

## Tablas

| Tabla | Filas | PK | Tiempo | FKs |
|---|---:|---|---|---|
| customer | 15,000 | customer_id | signup_date | — |
| seller | 600 | seller_id | join_date | — |
| category | 23 | category_id | — | parent_category_id → category |
| product | 3,750 | product_id | listed_at | seller_id, category_id |
| orders | 94,741 | order_id | order_date | customer_id |
| order_item | 148,512 | order_item_id | order_date | order_id, product_id |
| shipment | 94,182 | shipment_id | delivered_at | order_id |
| review | 39,243 | review_id | review_date | customer_id, product_id |
| product_return | 19,613 | return_id | return_date | order_item_id |
| view | 382,570 | view_id | view_time | customer_id, product_id |

Splits: `val_timestamp = 2025-09-01`, `test_timestamp = 2026-01-01`.

## Diagrama ER

```mermaid
erDiagram
  CUSTOMER ||--o{ ORDERS : hace
  CUSTOMER ||--o{ REVIEW : escribe
  CUSTOMER ||--o{ VIEW : navega
  ORDERS ||--|{ ORDER_ITEM : contiene
  ORDERS ||--o| SHIPMENT : se_envia
  ORDER_ITEM ||--o| PRODUCT_RETURN : se_devuelve
  PRODUCT ||--o{ ORDER_ITEM : vendido_en
  PRODUCT ||--o{ REVIEW : recibe
  PRODUCT ||--o{ VIEW : visto_en
  SELLER ||--o{ PRODUCT : publica
  CATEGORY ||--o{ PRODUCT : clasifica
  CATEGORY ||--o{ CATEGORY : padre_de
  CUSTOMER { int customer_id PK
    timestamp signup_date
    string state
    string age_group
    string acquisition_channel
    bool is_premium }
  SELLER { int seller_id PK
    timestamp join_date
    string state
    string seller_type
    string fulfillment }
  CATEGORY { int category_id PK
    string name
    int parent_category_id FK }
  PRODUCT { int product_id PK
    int seller_id FK
    int category_id FK
    timestamp listed_at
    string title
    string brand
    float price }
  ORDERS { int order_id PK
    int customer_id FK
    timestamp order_date
    string payment_method
    string shipping_state
    float shipping_cost }
  ORDER_ITEM { int order_item_id PK
    int order_id FK
    int product_id FK
    timestamp order_date
    int quantity
    float unit_price
    float discount_pct }
  SHIPMENT { int shipment_id PK
    int order_id FK
    string carrier
    timestamp shipped_at
    timestamp delivered_at
    int promised_days
    int delay_days }
  REVIEW { int review_id PK
    int customer_id FK
    int product_id FK
    timestamp review_date
    int rating
    string review_text }
  PRODUCT_RETURN { int return_id PK
    int order_item_id FK
    timestamp return_date
    string reason }
  VIEW { int view_id PK
    int customer_id FK
    int product_id FK
    timestamp view_time
    bool added_to_cart }
```

## Señales ocultas (lo que el modelo tiene que descubrir)

- `engagement` del cliente (oculto) → frecuencia de compra y probabilidad de abandono.
- `reliability` del vendedor (oculta) → `shipment.delay_days`.
- `quality` del producto (oculta, parcialmente heredada del vendedor) → `review.rating` y devoluciones.
- Las malas experiencias (envío tarde, devolución, rating ≤ 2) aumentan el churn del cliente.
  Esa señal vive a 2-4 saltos: `customer → orders → shipment` y `customer → orders → order_item → product → seller`.
- Preferencias de categoría por cliente + recompra de consumibles → recomendación.
- Vistas / carrito días antes de la compra → señal para recomendación y churn.
- Estacionalidad: Hot Sale (fin de mayo), Buen Fin (mediados de noviembre), diciembre.

## Tareas

| Tarea | Tipo | Entidad | Ventana | Métrica |
|---|---|---|---|---|
| customer-churn | clasificación binaria | customer (activos últimos 180 d) | 90 días | AUROC |
| customer-ltv | regresión | customer (activos últimos 180 d) | 90 días | NMAE |
| product-sales | regresión | product (listados) | 30 días | NMAE |
| customer-product-purchase | recomendación | customer → product | 30 días | MAP@10 |
| review-rating | autocomplete (regresión) | review (sin `review_text`) | — | NMAE |

## Baselines (test, LightGBM)

| Tarea | Baseline trivial | LightGBM "plano" (1 salto) | LightGBM "relacional" (2-4 saltos) |
|---|---|---|---|
| customer-churn (AUROC ↑) | 0.50 | 0.789 | 0.805 |
| customer-ltv (NMAE ↓) | 0.289 (cero) | 0.268 | 0.267 |
| product-sales (NMAE ↓) | 0.450 (cero) | 0.381 | 0.374 |
| customer-product-purchase (MAP@10 ↑) | 0.013 (populares) | — | 0.135 (historial + vistas + populares) |

El modelo RDL (GNN + RelBench) debería superar la columna "relacional" sin escribir features a mano.

## Uso

```python
from relbench.load import load_dataset
ds = load_dataset("rel-tienda")          # carpeta local
db = ds.get_db()
task = ds.load_task("customer-churn")
train = task.get_table("train")
```

Regenerar desde cero:

```bash
python generate_rel_tienda.py --out rel-tienda --customers 15000 --seed 42
python relbench/byod/reindex_dataset.py rel-tienda
python build_tasks.py rel-tienda
python -m relbench.validate rel-tienda
python baselines.py rel-tienda
```
