"""
Baselines tabulares para rel-tienda: verifican que las tareas se pueden aprender y
miden cuánto aporta la información relacional (multi-salto).

Para cada tarea se entrenan dos LightGBM:
  * "plano"      -> solo la tabla de la entidad + RFM de pedidos (1 salto)
  * "relacional" -> + vistas, envíos, devoluciones, reseñas, vendedores (2-4 saltos)
Esto es justo lo que RDL (GNN sobre el grafo de la BD) aprende sin feature engineering.

    python baselines.py rel-tienda
"""

import sys

import duckdb
import lightgbm as lgb
import numpy as np
import pandas as pd
from relbench.load import load_dataset

ROOT = sys.argv[1] if len(sys.argv) > 1 else "rel-tienda"
ds = load_dataset(ROOT)
DB = ds.get_db(upto_test_timestamp=False)   # las features solo usan filas <= timestamp


def con_with(labels: pd.DataFrame):
    con = duckdb.connect()
    for name, t in DB.table_dict.items():
        con.register(name, t.df)
    con.register("L", labels)
    return con


CUSTOMER_FLAT = """
SELECT L.timestamp, L.customer_id,
  c.is_premium::INT AS is_premium, c.age_group, c.acquisition_channel, c.state,
  date_diff('day', c.signup_date, L.timestamp) AS dias_desde_alta,
  (SELECT COUNT(*) FROM orders o WHERE o.customer_id=L.customer_id AND o.order_date<=L.timestamp
     AND o.order_date > L.timestamp - INTERVAL 30 DAY)  AS ped_30,
  (SELECT COUNT(*) FROM orders o WHERE o.customer_id=L.customer_id AND o.order_date<=L.timestamp
     AND o.order_date > L.timestamp - INTERVAL 90 DAY)  AS ped_90,
  (SELECT COUNT(*) FROM orders o WHERE o.customer_id=L.customer_id AND o.order_date<=L.timestamp) AS ped_total,
  (SELECT date_diff('day', MAX(o.order_date), L.timestamp) FROM orders o
     WHERE o.customer_id=L.customer_id AND o.order_date<=L.timestamp) AS recencia,
  (SELECT SUM(oi.quantity*oi.unit_price*(1-oi.discount_pct)) FROM orders o JOIN order_item oi USING(order_id)
     WHERE o.customer_id=L.customer_id AND o.order_date<=L.timestamp
     AND o.order_date > L.timestamp - INTERVAL 90 DAY) AS gasto_90,
  (SELECT SUM(oi.quantity*oi.unit_price*(1-oi.discount_pct)) FROM orders o JOIN order_item oi USING(order_id)
     WHERE o.customer_id=L.customer_id AND o.order_date<=L.timestamp) AS gasto_total
FROM L JOIN customer c USING(customer_id)
"""

CUSTOMER_REL = """
SELECT L.timestamp, L.customer_id,
  (SELECT COUNT(*) FROM view v WHERE v.customer_id=L.customer_id AND v.view_time<=L.timestamp
     AND v.view_time > L.timestamp - INTERVAL 30 DAY) AS vistas_30,
  (SELECT SUM(v.added_to_cart::INT) FROM view v WHERE v.customer_id=L.customer_id AND v.view_time<=L.timestamp
     AND v.view_time > L.timestamp - INTERVAL 30 DAY) AS carrito_30,
  (SELECT AVG(s.delay_days) FROM shipment s JOIN orders o USING(order_id)
     WHERE o.customer_id=L.customer_id AND s.delivered_at<=L.timestamp) AS retraso_prom,
  (SELECT SUM((s.delay_days>1)::INT) FROM shipment s JOIN orders o USING(order_id)
     WHERE o.customer_id=L.customer_id AND s.delivered_at<=L.timestamp
     AND s.delivered_at > L.timestamp - INTERVAL 180 DAY) AS envios_tarde_180,
  (SELECT COUNT(*) FROM product_return r JOIN order_item oi USING(order_item_id) JOIN orders o USING(order_id)
     WHERE o.customer_id=L.customer_id AND r.return_date<=L.timestamp
     AND r.return_date > L.timestamp - INTERVAL 180 DAY) AS devoluciones_180,
  (SELECT AVG(rv.rating) FROM review rv WHERE rv.customer_id=L.customer_id AND rv.review_date<=L.timestamp) AS rating_dado_prom,
  (SELECT SUM((rv.rating<=2)::INT) FROM review rv WHERE rv.customer_id=L.customer_id AND rv.review_date<=L.timestamp
     AND rv.review_date > L.timestamp - INTERVAL 180 DAY) AS malas_resenas_180,
  (SELECT COUNT(DISTINCT p.category_id) FROM orders o JOIN order_item oi USING(order_id) JOIN product p USING(product_id)
     WHERE o.customer_id=L.customer_id AND o.order_date<=L.timestamp) AS n_categorias
FROM L
"""

PRODUCT_FLAT = """
SELECT L.timestamp, L.product_id, p.price, p.category_id, p.brand,
  date_diff('day', p.listed_at, L.timestamp) AS dias_listado,
  (SELECT SUM(oi.quantity) FROM order_item oi WHERE oi.product_id=L.product_id AND oi.order_date<=L.timestamp
     AND oi.order_date > L.timestamp - INTERVAL 30 DAY) AS ventas_30,
  (SELECT SUM(oi.quantity) FROM order_item oi WHERE oi.product_id=L.product_id AND oi.order_date<=L.timestamp
     AND oi.order_date > L.timestamp - INTERVAL 90 DAY) AS ventas_90,
  (SELECT SUM(oi.quantity) FROM order_item oi WHERE oi.product_id=L.product_id AND oi.order_date<=L.timestamp) AS ventas_total
FROM L JOIN product p USING(product_id)
"""

PRODUCT_REL = """
SELECT L.timestamp, L.product_id,
  (SELECT COUNT(*) FROM view v WHERE v.product_id=L.product_id AND v.view_time<=L.timestamp
     AND v.view_time > L.timestamp - INTERVAL 14 DAY) AS vistas_14,
  (SELECT SUM(v.added_to_cart::INT) FROM view v WHERE v.product_id=L.product_id AND v.view_time<=L.timestamp
     AND v.view_time > L.timestamp - INTERVAL 14 DAY) AS carrito_14,
  (SELECT AVG(rv.rating) FROM review rv WHERE rv.product_id=L.product_id AND rv.review_date<=L.timestamp) AS rating_prom,
  (SELECT COUNT(*) FROM product_return r JOIN order_item oi USING(order_item_id)
     WHERE oi.product_id=L.product_id AND r.return_date<=L.timestamp) AS devoluciones,
  (SELECT AVG(s.delay_days) FROM product p2 JOIN product p3 ON p3.seller_id=p2.seller_id
     JOIN order_item oi ON oi.product_id=p3.product_id JOIN shipment s ON s.order_id=oi.order_id
     WHERE p2.product_id=L.product_id AND s.delivered_at<=L.timestamp) AS retraso_vendedor,
  (SELECT COUNT(DISTINCT o.customer_id) FROM order_item oi JOIN orders o USING(order_id)
     WHERE oi.product_id=L.product_id AND o.order_date<=L.timestamp
     AND o.order_date > L.timestamp - INTERVAL 90 DAY) AS compradores_90
FROM L
"""


def features(labels, key, flat_sql, rel_sql):
    con = con_with(labels[["timestamp", key]].drop_duplicates())
    f = con.sql(flat_sql).df()
    r = con.sql(rel_sql).df()
    con.close()
    out = labels.merge(f, on=["timestamp", key], how="left")
    out_rel = out.merge(r, on=["timestamp", key], how="left")
    return out, out_rel


def fit_eval(task, target, key, flat_sql, rel_sql, objective):
    tr = task.get_table("train", mask_input_cols=False).df
    te = task.get_table("test", mask_input_cols=False).df
    va = task.get_table("val", mask_input_cols=False).df
    res = {}
    (trf, trr), (vaf, var_), (tef, ter) = (features(d, key, flat_sql, rel_sql) for d in (tr, va, te))
    for name, (Xtr, Xva, Xte) in {"plano": (trf, vaf, tef), "relacional": (trr, var_, ter)}.items():
        cols = [c for c in Xtr.columns if c not in ("timestamp", key, target)]
        cats = {c: sorted(Xtr[c].dropna().unique()) for c in cols
                if not pd.api.types.is_numeric_dtype(Xtr[c]) or c == "category_id"}

        def prep(d):
            d = d[cols].copy()
            for c, cs in cats.items():
                d[c] = pd.Categorical(d[c], categories=cs)
            return d.apply(lambda s: s.astype(float) if pd.api.types.is_bool_dtype(s) else s)
        y = Xtr[target].values
        if objective == "regression":
            y = np.log1p(y)       # objetivo sesgado -> log
            obj = "regression_l1"  # NMAE ~ MAE -> L1 sobre log
        else:
            obj = "binary"
        Model = lgb.LGBMRegressor if objective == "regression" else lgb.LGBMClassifier
        m = Model(objective=obj, n_estimators=2000, learning_rate=0.03, num_leaves=31,
                              min_child_samples=40, subsample=0.8, subsample_freq=1,
                              colsample_bytree=0.8, verbose=-1)
        yva = np.log1p(Xva[target].values) if objective == "regression" else Xva[target].values
        m.fit(prep(Xtr), y, eval_set=[(prep(Xva), yva)],
              callbacks=[lgb.early_stopping(100, verbose=False)])
        if objective == "regression":
            p = np.expm1(m.predict(prep(Xte)))
        else:
            p = m.predict_proba(prep(Xte))[:, 1]
        res[name] = task.evaluate(p)
        if name == "relacional":
            imp = pd.Series(m.booster_.feature_importance("gain"), index=cols).sort_values(ascending=False)
            res["top_features"] = list(imp.index[:6])
    return res


print("\n=== customer-churn (AUROC, más alto mejor) ===")
t = ds.load_task("customer-churn")
print(fit_eval(t, "churn", "customer_id", CUSTOMER_FLAT, CUSTOMER_REL, "binary"))

print("\n=== customer-ltv (NMAE, más bajo mejor) ===")
t = ds.load_task("customer-ltv")
te = t.get_table("test", mask_input_cols=False).df
print("cero para todos:", t.evaluate(np.zeros(len(te))))
print(fit_eval(t, "ltv", "customer_id", CUSTOMER_FLAT, CUSTOMER_REL, "regression"))

print("\n=== product-sales (NMAE, más bajo mejor) ===")
t = ds.load_task("product-sales")
te = t.get_table("test", mask_input_cols=False).df
print("cero para todos:", t.evaluate(np.zeros(len(te))))
print(fit_eval(t, "sales", "product_id", PRODUCT_FLAT, PRODUCT_REL, "regression"))

# ---------------------------------------------------------------- recomendación
print("\n=== customer-product-purchase (MAP@10, más alto mejor) ===")
t = ds.load_task("customer-product-purchase")
te = t.get_table("test", mask_input_cols=False).df
T = ds.test_timestamp
items = DB.table_dict["order_item"].df
orders = DB.table_dict["orders"].df
views = DB.table_dict["view"].df
hist = items[items.order_date <= T].merge(orders[["order_id", "customer_id"]], on="order_id")
recent = hist[hist.order_date > T - pd.Timedelta(days=60)]
popular = recent.groupby("product_id").quantity.sum().sort_values(ascending=False).index.to_numpy()

pred_pop = np.tile(popular[:10], (len(te), 1))
print("populares globales:", t.evaluate(pred_pop))

v = views[(views.view_time <= T) & (views.view_time > T - pd.Timedelta(days=30))]
score = (pd.concat([
    v.assign(s=np.where(v.added_to_cart, 3.0, 1.0))[["customer_id", "product_id", "s"]],
    hist.assign(s=2.0)[["customer_id", "product_id", "s"]],
]).groupby(["customer_id", "product_id"]).s.sum().reset_index()
 .sort_values(["customer_id", "s"], ascending=[True, False]))
per_user = score.groupby("customer_id").product_id.apply(lambda s: s.to_numpy()[:10]).to_dict()
pred = []
for c in te.customer_id:
    own = list(per_user.get(c, []))
    fill = [p for p in popular if p not in own][: 10 - len(own)]
    pred.append(own + fill)
print("historial + vistas + populares:", t.evaluate(np.array(pred)))
