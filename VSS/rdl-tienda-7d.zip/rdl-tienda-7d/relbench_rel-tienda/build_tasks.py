"""
Define las tareas de predicción de rel-tienda (formato BYOD de RelBench) y materializa
sus labels train/val/test.

    python build_tasks.py rel-tienda
"""

import sys
from pathlib import Path

from relbench.load import load_dataset
from relbench.manifest import TaskManifest

# Población "activa": clientes con al menos un pedido en los 180 días previos a t.
CHURN_SQL = """
WITH activos AS (
    SELECT DISTINCT t.timestamp, o.customer_id
    FROM timestamps t
    JOIN orders o
      ON o.order_date <= t.timestamp
     AND o.order_date >  t.timestamp - INTERVAL '180 days'
)
SELECT
    a.timestamp,
    a.customer_id,
    CAST(CASE WHEN COUNT(f.order_id) = 0 THEN 1 ELSE 0 END AS BIGINT) AS churn
FROM activos a
LEFT JOIN orders f
  ON f.customer_id = a.customer_id
 AND f.order_date >  a.timestamp
 AND f.order_date <= a.timestamp + INTERVAL '{timedelta}'
GROUP BY a.timestamp, a.customer_id
"""

LTV_SQL = """
WITH activos AS (
    SELECT DISTINCT t.timestamp, o.customer_id
    FROM timestamps t
    JOIN orders o
      ON o.order_date <= t.timestamp
     AND o.order_date >  t.timestamp - INTERVAL '180 days'
)
SELECT
    a.timestamp,
    a.customer_id,
    CAST(COALESCE(SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct)), 0) AS DOUBLE) AS ltv
FROM activos a
LEFT JOIN orders f
  ON f.customer_id = a.customer_id
 AND f.order_date >  a.timestamp
 AND f.order_date <= a.timestamp + INTERVAL '{timedelta}'
LEFT JOIN order_item oi ON oi.order_id = f.order_id
GROUP BY a.timestamp, a.customer_id
"""

# Productos ya listados en t: unidades vendidas en los próximos 30 días.
SALES_SQL = """
SELECT
    t.timestamp,
    p.product_id,
    CAST(COALESCE(SUM(oi.quantity), 0) AS DOUBLE) AS sales
FROM timestamps t
JOIN product p ON p.listed_at <= t.timestamp
LEFT JOIN order_item oi
  ON oi.product_id = p.product_id
 AND oi.order_date >  t.timestamp
 AND oi.order_date <= t.timestamp + INTERVAL '{timedelta}'
GROUP BY t.timestamp, p.product_id
"""

# Recomendación: qué productos comprará cada cliente en los próximos 30 días.
PURCHASE_SQL = """
SELECT
    t.timestamp,
    o.customer_id,
    LIST(DISTINCT oi.product_id) AS product_id
FROM timestamps t
JOIN orders o
  ON o.order_date >  t.timestamp
 AND o.order_date <= t.timestamp + INTERVAL '{timedelta}'
JOIN order_item oi ON oi.order_id = o.order_id
GROUP BY t.timestamp, o.customer_id
"""

TASKS = [
    TaskManifest(
        name="customer-churn", kind="forecast", task_type="binary_classification",
        description="Para clientes con compras en los últimos 180 días: ¿dejarán de comprar "
                    "en los próximos 90 días?",
        entity_table="customer", entity_col="customer_id", target_col="churn",
        time_col="timestamp", timedelta="90 days", sql=CHURN_SQL),
    TaskManifest(
        name="customer-ltv", kind="forecast", task_type="regression",
        description="Gasto total (MXN, con descuento) de cada cliente activo en los próximos 90 días.",
        entity_table="customer", entity_col="customer_id", target_col="ltv",
        time_col="timestamp", timedelta="90 days", sql=LTV_SQL),
    TaskManifest(
        name="product-sales", kind="forecast", task_type="regression",
        description="Unidades vendidas de cada producto listado en los próximos 30 días.",
        entity_table="product", entity_col="product_id", target_col="sales",
        time_col="timestamp", timedelta="30 days", sql=SALES_SQL),
    TaskManifest(
        name="customer-product-purchase", kind="forecast", task_type="recommendation",
        description="Top-10 productos que cada cliente comprará en los próximos 30 días (MAP@10).",
        src_entity_table="customer", src_entity_col="customer_id",
        dst_entity_table="product", dst_entity_col="product_id",
        target_col="product_id", time_col="timestamp", timedelta="30 days", eval_k=10,
        sql=PURCHASE_SQL),
    TaskManifest(
        name="review-rating", kind="autocomplete", task_type="regression",
        description="Predecir el rating (1-5) de una reseña sin ver su texto.",
        entity_table="review", target_col="rating",
        remove_columns=[["review", "review_text"]]),
]


def main(root: Path):
    for tm in TASKS:
        tm.validate()
        tm.save(root / "tasks" / tm.name / "manifest.yaml")
    ds = load_dataset(str(root))
    db_full = None
    for tm in TASKS:
        task = ds.load_task(tm.name, regenerate=True)
        if db_full is None or tm.remove_columns:
            db = task.get_db(upto_test_timestamp=False)
        else:
            db = db_full
        if not tm.remove_columns:
            db_full = db
        for split in ["train", "val", "test"]:
            tbl = task.get_table(split, mask_input_cols=False, db=db)
            tbl.df.to_parquet(root / "tasks" / tm.name / f"{split}.parquet", index=False)
            print(f"{tm.name:28s} {split:5s} {len(tbl.df):>8,d} filas")


if __name__ == "__main__":
    main(Path(sys.argv[1] if len(sys.argv) > 1 else "rel-tienda"))
