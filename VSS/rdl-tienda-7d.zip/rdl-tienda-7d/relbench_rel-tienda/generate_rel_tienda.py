"""
Generador sintético de `rel-tienda`: un marketplace e-commerce mexicano al estilo de
los datasets de RelBench (rel-amazon, rel-hm, rel-avito).

Produce una carpeta BYOD de RelBench:
    rel-tienda/
        manifest.yaml
        db/<tabla>.parquet

Señales latentes (lo que un modelo debería descubrir):
  * customer.engagement  (oculto)  -> frecuencia de compra y probabilidad de abandono
  * seller.reliability   (oculto)  -> retrasos de envío (shipment.delay_days)
  * product.quality      (oculto)  -> rating de reseñas y devoluciones
  * Malas experiencias (retraso, devolución, rating <= 2) aumentan el churn del cliente.
    => El churn depende de información a 2-3 saltos:
       customer -> orders -> shipment / order_item -> product -> seller
  * Preferencias de categoría por cliente + recompra de productos -> recomendación
  * Vistas (view) de productos días antes de comprarlos -> señal para recomendación
  * Estacionalidad: Hot Sale (fin de mayo), Buen Fin (mediados de nov), Diciembre

Uso:
    python generate_rel_tienda.py --out rel-tienda --customers 15000 --seed 42
"""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

START = pd.Timestamp("2024-01-01")
END = pd.Timestamp("2026-06-30")
VAL_TS = "2025-09-01"
TEST_TS = "2026-01-01"

STATES = ["CDMX", "Jalisco", "Nuevo León", "Estado de México", "Puebla", "Guanajuato",
          "Querétaro", "Yucatán", "Veracruz", "Baja California", "Chihuahua", "Sonora"]
STATE_P = np.array([18, 12, 11, 16, 6, 6, 5, 4, 6, 6, 5, 5], float)
STATE_P /= STATE_P.sum()

# (padre, hijo, precio_base_MXN, tasa_base_devolución, consumible)
CATEGORIES = [
    ("Electrónica", "Smartphones", 6500, -2.0, False),
    ("Electrónica", "Audífonos", 900, -2.3, False),
    ("Electrónica", "Accesorios de cómputo", 450, -2.6, False),
    ("Hogar", "Cocina", 600, -2.8, False),
    ("Hogar", "Decoración", 350, -2.5, False),
    ("Hogar", "Limpieza", 180, -3.6, True),
    ("Moda", "Ropa", 420, -1.6, False),
    ("Moda", "Calzado", 950, -1.4, False),
    ("Belleza", "Perfumes", 1100, -3.0, True),
    ("Belleza", "Cuidado de la piel", 320, -3.2, True),
    ("Deportes", "Fitness", 700, -2.4, False),
    ("Deportes", "Suplementos", 550, -3.4, True),
    ("Mascotas", "Alimento para mascotas", 480, -3.8, True),
    ("Libros", "Libros", 280, -3.5, False),
    ("Juguetes", "Juguetes", 500, -2.7, False),
]
BRANDS = ["Aurora", "Nexo", "Kali", "Montera", "Zuma", "Ixchel", "Orbe", "Tlali",
          "Volcán", "Brisa", "Maya", "Norte", "Coral", "Fénix", "Selva", "Cobalto"]
CARRIERS = ["Estafeta", "DHL", "FedEx", "Paquetexpress", "Logística propia"]
PAYMENTS = ["tarjeta_credito", "tarjeta_debito", "oxxo", "transferencia", "meses_sin_intereses"]
RETURN_REASONS = ["no_coincide_descripcion", "defectuoso", "talla_incorrecta",
                  "llegó_tarde", "ya_no_lo_quiero"]

POS_TXT = ["Excelente producto, llegó muy bien.", "Muy buena calidad, lo recomiendo.",
           "Cumple perfecto, volvería a comprar.", "Me encantó, superó lo esperado."]
MID_TXT = ["Está bien por el precio.", "Cumple, aunque esperaba un poco más.",
           "Normal, nada especial.", "Buen producto pero el empaque llegó dañado."]
NEG_TXT = ["Mala calidad, no lo recomiendo.", "Llegó tarde y no funciona bien.",
           "No coincide con la descripción.", "Muy decepcionante, pedí devolución."]


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def season(t: pd.Timestamp) -> float:
    """Multiplicador estacional de la tasa de compra."""
    m = 1.0
    if t.month == 11 and 10 <= t.day <= 20:   # Buen Fin
        m = 2.6
    elif t.month == 12:
        m = 1.7 if t.day < 24 else 1.2
    elif t.month == 5 and t.day >= 24 or (t.month == 6 and t.day <= 2):  # Hot Sale
        m = 2.2
    elif t.month in (1, 2):
        m = 0.8
    return m


SEASON_MAX = 2.6


def main(out: Path, n_customers: int, seed: int):
    rng = np.random.default_rng(seed)
    total_days = (END - START).days

    # ------------------------------------------------------------------ category
    parents = sorted({c[0] for c in CATEGORIES})
    cat_rows = [{"category_id": i, "name": p, "parent_category_id": None}
                for i, p in enumerate(parents)]
    parent_id = {p: i for i, p in enumerate(parents)}
    leaf_ids, leaf_info = [], {}
    for c in CATEGORIES:
        cid = len(cat_rows)
        cat_rows.append({"category_id": cid, "name": c[1], "parent_category_id": parent_id[c[0]]})
        leaf_ids.append(cid)
        leaf_info[cid] = dict(price=c[2], ret=c[3], consumable=c[4])
    category = pd.DataFrame(cat_rows)
    category["parent_category_id"] = category["parent_category_id"].astype("Int64")
    n_leaf = len(leaf_ids)

    # ------------------------------------------------------------------ seller
    n_sellers = max(50, n_customers // 25)
    seller_rel = rng.normal(0, 1, n_sellers)                       # oculto
    seller = pd.DataFrame({
        "seller_id": np.arange(n_sellers),
        "join_date": START - pd.to_timedelta(rng.integers(0, 900, n_sellers), "D")
        + pd.to_timedelta((rng.random(n_sellers) < 0.3) * rng.integers(0, total_days - 120, n_sellers), "D"),
        "state": rng.choice(STATES, n_sellers, p=STATE_P),
        "seller_type": rng.choice(["oficial", "independiente", "distribuidor"], n_sellers, p=[.2, .6, .2]),
        "fulfillment": np.where(seller_rel + rng.normal(0, .7, n_sellers) > .6, "full_marketplace", "propio"),
    })
    seller_spec = rng.integers(0, n_leaf, n_sellers)               # categoría principal

    # ------------------------------------------------------------------ product
    n_products = n_customers // 4
    p_seller = rng.integers(0, n_sellers, n_products)
    p_leaf_idx = np.where(rng.random(n_products) < 0.7, seller_spec[p_seller], rng.integers(0, n_leaf, n_products))
    p_cat = np.array(leaf_ids)[p_leaf_idx]
    p_quality = 0.5 * seller_rel[p_seller] + rng.normal(0, 0.9, n_products)   # oculto
    p_pop = rng.lognormal(0, 1.1, n_products)                                  # oculto
    base_price = np.array([leaf_info[c]["price"] for c in p_cat])
    price = np.round(base_price * rng.lognormal(0.1 * p_quality, 0.45), -1) - 1
    s_join = seller["join_date"].values[p_seller]
    lo = np.maximum(s_join, np.datetime64(START - pd.Timedelta(days=60)))
    span = (np.datetime64(END - pd.Timedelta(days=30)) - lo).astype("timedelta64[D]").astype(int)
    # 45% del catálogo existe antes del arranque; el resto se lista con el tiempo
    off = np.where(rng.random(n_products) < 0.45, rng.integers(0, 60, n_products),
                   (rng.random(n_products) * span).astype(int))
    listed_at = lo + off.astype("timedelta64[D]")
    names = category.set_index("category_id")["name"]
    brand = rng.choice(BRANDS, n_products)
    product = pd.DataFrame({
        "product_id": np.arange(n_products),
        "seller_id": p_seller,
        "category_id": p_cat,
        "listed_at": pd.to_datetime(listed_at),
        "title": [f"{names[c]} {b} modelo {rng.integers(100, 999)}" for c, b in zip(p_cat, brand)],
        "brand": brand,
        "price": price.astype(float),
    })

    # índice por categoría ordenado por fecha de listado -> muestreo eficiente
    cat_index = {}
    for c in leaf_ids:
        idx = np.where(p_cat == c)[0]
        idx = idx[np.argsort(product["listed_at"].values[idx])]
        cat_index[c] = (idx, product["listed_at"].values[idx], np.cumsum(p_pop[idx]))

    def sample_product(c, t64):
        idx, lst, cum = cat_index[c]
        k = np.searchsorted(lst, t64, side="right")
        if k == 0:
            return -1
        return idx[np.searchsorted(cum[:k], rng.random() * cum[k - 1])]

    # ------------------------------------------------------------------ customer
    n = n_customers
    engagement = rng.normal(0, 1, n)                                            # oculto
    channel = rng.choice(["organico", "redes_sociales", "referido", "google_ads", "afiliados"], n,
                         p=[.3, .25, .15, .2, .1])
    ch_eff = pd.Series({"organico": .15, "redes_sociales": -.25, "referido": .35,
                        "google_ads": 0, "afiliados": -.3})[channel].values
    is_premium = (engagement + rng.normal(0, 1, n) > 1.2)
    # altas: más al inicio + crecimiento + picos en Buen Fin
    signup_off = np.where(rng.random(n) < 0.15, rng.integers(0, 60, n),
                          (rng.beta(1.5, 1.0, n) * (total_days - 60)).astype(int))
    signup = START + pd.to_timedelta(signup_off, "D") + pd.to_timedelta(rng.integers(0, 86400, n), "s")
    customer = pd.DataFrame({
        "customer_id": np.arange(n),
        "signup_date": signup,
        "state": rng.choice(STATES, n, p=STATE_P),
        "age_group": rng.choice(["18-24", "25-34", "35-44", "45-54", "55+"], n, p=[.18, .34, .24, .14, .10]),
        "acquisition_channel": channel,
        "is_premium": is_premium,
    })
    cat_pref = rng.dirichlet(np.full(n_leaf, 0.35), n)

    # ------------------------------------------------------------------ simulación
    orders, items, ships, reviews, returns, views = [], [], [], [], [], []
    oid = iid = 0
    end64 = np.datetime64(END)
    for c in range(n):
        e = engagement[c]
        base_rate = np.exp(-3.4 + 0.55 * e + 0.45 * is_premium[c] + ch_eff[c])  # pedidos/día
        t = signup[c] + pd.Timedelta(hours=float(rng.exponential(48)))
        bought = []
        bad = 0.0                                                # memoria de malas experiencias
        state_c = customer.at[c, "state"]
        while True:
            rate = base_rate * np.exp(-0.5 * bad)
            # proceso de Poisson no homogéneo por thinning
            t = t + pd.Timedelta(days=float(rng.exponential(1 / (rate * SEASON_MAX))))
            if t > END:
                break
            if rng.random() > season(t) / SEASON_MAX:
                continue
            t64 = np.datetime64(t)
            # --- items del pedido
            n_items = 1 + rng.poisson(0.5 + 0.2 * is_premium[c])
            chosen = []
            for _ in range(n_items):
                if bought and rng.random() < 0.28:
                    p = bought[rng.integers(len(bought))]               # recompra
                    if not leaf_info[p_cat[p]]["consumable"] and rng.random() < 0.7:
                        p = sample_product(p_cat[p], t64)               # misma categoría
                else:
                    p = sample_product(leaf_ids[rng.choice(n_leaf, p=cat_pref[c])], t64)
                if p >= 0 and p not in chosen:
                    chosen.append(p)
            if not chosen:
                continue
            # --- vistas previas (señal para recomendación)
            for p in chosen:
                for _ in range(1 + rng.poisson(1.2)):
                    vt = t - pd.Timedelta(hours=float(rng.exponential(60)))
                    views.append((c, p, max(vt, signup[c]), rng.random() < 0.6))
            # --- envío: el vendedor del primer item define el envío
            s = p_seller[chosen[0]]
            promised = int(rng.choice([2, 3, 5, 7], p=[.25, .35, .25, .15]))
            delay = int(rng.poisson(np.exp(-0.2 - 0.9 * seller_rel[s])))
            if seller.at[s, "fulfillment"] == "full_marketplace":
                delay = max(0, delay - 1)
            shipped = t + pd.Timedelta(hours=float(rng.uniform(4, 40)))
            delivered = t + pd.Timedelta(days=promised + delay, hours=float(rng.uniform(0, 12)))
            late = delay > 1
            orders.append({"order_id": oid, "customer_id": c, "order_date": t,
                           "payment_method": rng.choice(PAYMENTS, p=[.35, .25, .15, .1, .15]),
                           "shipping_state": state_c,
                           "shipping_cost": float(0 if is_premium[c] else rng.choice([0, 79, 99, 149]))})
            ships.append({"order_id": oid, "carrier": rng.choice(CARRIERS), "shipped_at": shipped,
                          "delivered_at": delivered, "promised_days": promised, "delay_days": delay})
            experience = -0.6 if late else 0.15
            for p in chosen:
                qty = 1 + rng.poisson(0.25 + 0.6 * leaf_info[p_cat[p]]["consumable"])
                disc = float(rng.choice([0, 0, 0, .1, .15, .3]) if season(t) > 1.5 else rng.choice([0, 0, 0, 0, .1]))
                items.append({"order_item_id": iid, "order_id": oid, "product_id": p, "order_date": t,
                              "quantity": int(qty), "unit_price": float(product.at[p, "price"]),
                              "discount_pct": disc})
                # devolución
                pr = sigmoid(leaf_info[p_cat[p]]["ret"] - 1.0 * p_quality[p] + 0.9 * late)
                if rng.random() < pr:
                    returns.append({"order_item_id": iid,
                                    "return_date": delivered + pd.Timedelta(days=float(rng.uniform(1, 15))),
                                    "late": late})
                    experience -= 0.8
                # reseña
                rating = int(np.clip(np.round(3.7 + 0.9 * p_quality[p] - 0.7 * late + rng.normal(0, 0.8)), 1, 5))
                if rng.random() < 0.18 + 0.12 * (rating in (1, 5)) + 0.1 * (e > 0.5):
                    txt = rng.choice(POS_TXT if rating >= 4 else MID_TXT if rating == 3 else NEG_TXT)
                    reviews.append({"customer_id": c, "product_id": p,
                                    "review_date": delivered + pd.Timedelta(days=float(rng.exponential(4))),
                                    "rating": rating, "review_text": str(txt)})
                if rating <= 2:
                    experience -= 0.4
                bought.append(p)
                iid += 1
            oid += 1
            # --- abandono (churn) del cliente tras el pedido
            bad = 0.6 * bad + max(0.0, -experience)
            p_churn = sigmoid(-2.6 - 0.55 * e - 0.6 * is_premium[c] + 0.9 * bad)
            if rng.random() < p_churn:
                break
        # navegación sin compra (ruido + interés por categorías preferidas)
        n_browse = rng.poisson(3 + 2 * max(e, 0))
        last = orders[-1]["order_date"] if orders and orders[-1]["customer_id"] == c else signup[c]
        horizon = (min(last + pd.Timedelta(days=60), END) - signup[c]).total_seconds()
        for _ in range(n_browse):
            vt = signup[c] + pd.Timedelta(seconds=float(rng.random() * max(horizon, 1)))
            p = sample_product(leaf_ids[rng.choice(n_leaf, p=cat_pref[c])], np.datetime64(vt))
            if p >= 0:
                views.append((c, p, vt, rng.random() < 0.15))

    orders = pd.DataFrame(orders)
    order_item = pd.DataFrame(items)
    shipment = pd.DataFrame(ships)
    shipment.insert(0, "shipment_id", np.arange(len(shipment)))
    review = pd.DataFrame(reviews)
    review.insert(0, "review_id", np.arange(len(review)))
    product_return = pd.DataFrame(returns)
    late_r = product_return.pop("late").values
    product_return["reason"] = [rng.choice(RETURN_REASONS, p=[.2, .2, .15, .35, .1] if lt else [.32, .27, .2, .03, .18])
                                for lt in late_r]
    product_return.insert(0, "return_id", np.arange(len(product_return)))
    view = pd.DataFrame(views, columns=["customer_id", "product_id", "view_time", "added_to_cart"])
    view.insert(0, "view_id", np.arange(len(view)))

    # recorta eventos que caen después del fin de los datos
    shipment = shipment[shipment["delivered_at"] <= END]
    review = review[review["review_date"] <= END]
    product_return = product_return[product_return["return_date"] <= END]
    view = view[view["view_time"] <= END]

    tables = {
        "customer": customer, "seller": seller, "category": category, "product": product,
        "orders": orders, "order_item": order_item, "shipment": shipment,
        "review": review, "product_return": product_return, "view": view,
    }
    specs = {
        "customer": dict(pkey="customer_id", time_col="signup_date", fkeys={}),
        "seller": dict(pkey="seller_id", time_col="join_date", fkeys={}),
        "category": dict(pkey="category_id", time_col=None, fkeys={"parent_category_id": "category"}),
        "product": dict(pkey="product_id", time_col="listed_at",
                        fkeys={"seller_id": "seller", "category_id": "category"}),
        "orders": dict(pkey="order_id", time_col="order_date", fkeys={"customer_id": "customer"}),
        "order_item": dict(pkey="order_item_id", time_col="order_date",
                           fkeys={"order_id": "orders", "product_id": "product"}),
        "shipment": dict(pkey="shipment_id", time_col="delivered_at", fkeys={"order_id": "orders"}),
        "review": dict(pkey="review_id", time_col="review_date",
                       fkeys={"customer_id": "customer", "product_id": "product"}),
        "product_return": dict(pkey="return_id", time_col="return_date",
                               fkeys={"order_item_id": "order_item"}),
        "view": dict(pkey="view_id", time_col="view_time",
                     fkeys={"customer_id": "customer", "product_id": "product"}),
    }

    (out / "db").mkdir(parents=True, exist_ok=True)
    for name, df in tables.items():
        tc = specs[name]["time_col"]
        for col in df.columns:
            if pd.api.types.is_datetime64_any_dtype(df[col]):
                df[col] = df[col].astype("datetime64[us]").dt.floor("s")
        if tc:
            df = df.sort_values(tc, kind="stable")
        df.reset_index(drop=True).to_parquet(out / "db" / f"{name}.parquet", index=False)
        print(f"{name:15s} {len(df):>9,d} filas")

    manifest = {
        "name": "rel-tienda",
        "manifest_version": 1,
        "description": "Marketplace e-commerce mexicano sintético (clientes, vendedores, productos, "
                       "pedidos, envíos, reseñas, devoluciones y vistas). Estilo rel-amazon / rel-hm.",
        "val_timestamp": VAL_TS,
        "test_timestamp": TEST_TS,
        "tables": specs,
    }
    with open(out / "manifest.yaml", "w", encoding="utf-8") as f:
        yaml.safe_dump(manifest, f, sort_keys=False, allow_unicode=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="rel-tienda")
    ap.add_argument("--customers", type=int, default=15000)
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()
    main(Path(a.out), a.customers, a.seed)
