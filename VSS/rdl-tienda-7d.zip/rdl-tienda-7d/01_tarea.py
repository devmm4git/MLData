"""
Paso 1 · ¿Qué predecir?
    customer-buy-7d: para cada cliente que compró en los últimos 90 días,
    ¿hará al menos un pedido en los próximos 7 días? (clasificación binaria, AUROC)

Crea rel-tienda/tasks/customer-buy-7d/ (manifest + train/val/test.parquet).
    python 01_tarea.py ../rel-tienda
"""
import sys
from pathlib import Path

from relbench.load import load_dataset
from relbench.manifest import TaskManifest

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else "rel-tienda")

SQL = """
WITH activos AS (                      -- población en cada fecha de corte t
    SELECT DISTINCT t.timestamp, o.customer_id
    FROM timestamps t
    JOIN orders o
      ON o.order_date <= t.timestamp
     AND o.order_date >  t.timestamp - INTERVAL '90 days'
)
SELECT
    a.timestamp,
    a.customer_id,
    CAST(CASE WHEN COUNT(f.order_id) > 0 THEN 1 ELSE 0 END AS BIGINT) AS compra_7d
FROM activos a
LEFT JOIN orders f                     -- lo que pasa DESPUÉS de t (la etiqueta)
  ON f.customer_id = a.customer_id
 AND f.order_date >  a.timestamp
 AND f.order_date <= a.timestamp + INTERVAL '{timedelta}'
GROUP BY a.timestamp, a.customer_id
"""

tm = TaskManifest(
    name="customer-buy-7d", kind="forecast", task_type="binary_classification",
    description="Clientes con compras en los últimos 90 días: ¿harán al menos un pedido en los próximos 7 días?",
    entity_table="customer", entity_col="customer_id", target_col="compra_7d",
    time_col="timestamp", timedelta="7 days",
    num_eval_timestamps=4,   # val y test = 4 semanas consecutivas cada uno (métrica más estable)
    sql=SQL,
)
tm.validate()
out = ROOT / "tasks" / tm.name
tm.save(out / "manifest.yaml")

ds = load_dataset(str(ROOT))
task = ds.load_task(tm.name, regenerate=True)
db = task.get_db(upto_test_timestamp=False)
for split in ["train", "val", "test"]:
    df = task.get_table(split, mask_input_cols=False, db=db).df
    df.to_parquet(out / f"{split}.parquet", index=False)
    print(f"{split:5s} filas={len(df):>8,d}  cortes={df.timestamp.nunique():>3d}  "
          f"positivos={df.compra_7d.mean():.1%}  rango={df.timestamp.min().date()}..{df.timestamp.max().date()}")
