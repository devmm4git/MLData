# rdl-tienda-7d — base de datos para probar RDL de punta a punta

Marketplace e-commerce mexicano sintético (ene-2024 → jun-2026), 10 tablas relacionadas.
Pensada para un primer caso de uso: **¿el cliente hará al menos un pedido en los próximos 7 días?**

## Contenido

| Carpeta / archivo | Qué es |
|---|---|
| `datos/*.csv` | Una tabla por archivo (nombres = tablas del esquema). Úsalo con `FUENTE = "csv"` y `CSV_DIR = "./datos"` en `rdl_pipeline.py`. |
| `esquema.mmd` | Diagrama ER en Mermaid. Pégalo en el bloque 1 de "Mapa de saltos RDL". |
| `tarea_customer_buy_7d/{train,val,test}.csv` | La tabla de tareas ya calculada: `timestamp` (corte t0), `customer_id`, `compra_7d` (0/1). |
| `relbench_rel-tienda/` | La misma base en formato RelBench BYOD (`manifest.yaml` + parquet + tareas). `relbench.load_dataset("relbench_rel-tienda")`. |
| `01_tarea.py` | Regenera la tarea con SQL (DuckDB) desde la carpeta RelBench. |
| `02_baselines.py` | Baselines: regla "semana pasada", recencia y LightGBM. |

## Tablas

| Tabla | Filas | PK | Columna de tiempo | FKs |
|---|---:|---|---|---|
| customer | 15,000 | customer_id | signup_date | — |
| seller | 600 | seller_id | join_date | — |
| category | 23 | category_id | — | parent_category_id → category |
| product | 3,750 | product_id | listed_at | seller_id, category_id |
| orders | 94,741 | order_id | order_date | customer_id |
| order_item | 148,512 | order_item_id | order_date | order_id, product_id |
| shipment | 94,182 | shipment_id | delivered_at | order_id |
| review | 39,243 | review_id | review_date | customer_id, product_id |
| product_return | 19,613 | return_id | return_date | order_item_id |
| view | 382,570 | view_id | view_time | customer_id, product_id |

Las llaves ya están re-indexadas a 0..n-1 y cada tabla con tiempo está ordenada por su fecha.
En `shipment` usa `delivered_at` como columna de tiempo (no `shipped_at`): así el retraso no se ve antes de que ocurra.
Las columnas de texto (`product.title`, `review.review_text`) puedes quitarlas si no quieres usar un modelo de texto.

## Paso 1 · Qué predecir

- **Entidad:** `customer`
- **Población en cada corte t0:** clientes con al menos un pedido en los 90 días previos.
- **Etiqueta:** `compra_7d = 1` si hay al menos un pedido en `orders` con `order_date` en (t0, t0 + 7 días].
- **Cortes:** cada 7 días.
- **Splits:** `val_timestamp = 2025-09-01`, `test_timestamp = 2026-01-01` (4 cortes semanales en val y en test).

| Split | Filas | Cortes | % positivos | Rango de t0 |
|---|---:|---:|---:|---|
| train | 233,808 | 86 | 14.3% | 2024-01-08 → 2025-08-25 |
| val | 15,642 | 4 | 13.3% | 2025-09-01 → 2025-09-22 |
| test | 19,736 | 4 | 9.5% | 2026-01-01 → 2026-01-22 |

En el bloque 9 de la página: entidad `customer`, "¿Ocurrirá un evento?", tabla de eventos `orders`,
ventana 7 días, corte cada 7 días, inicio de entrenamiento 2024-01-08, validación 2025-09-01,
prueba 2026-01-01, último corte 2026-01-22.

## Paso 2 · Baselines (ya calculados, AUROC)

| Modelo | Val | Test |
|---|---:|---:|
| A · Regla: compró la semana pasada (pedidos en los 7 días previos) | 0.561 | 0.562 |
| B · Regla: recencia (días desde el último pedido) | 0.633 | 0.664 |
| C · LightGBM, features básicas (cliente + pedidos) | 0.683 | 0.707 |
| D · LightGBM + features relacionales (vistas, envíos, devoluciones, reseñas) | 0.849 | 0.862 |

Lo que más pesa en D: días desde la última vista, vistas y carrito en los últimos 7 días, y recencia de compra.
La señal fuerte está en la tabla `view`, a un salto de `customer`. Con 2 capas la GNN también alcanza
`product`, `shipment`, `order_item` y `review`.

Para repetirlos: `pip install relbench duckdb lightgbm` y `python 02_baselines.py relbench_rel-tienda`.

## Paso 3 · RDL

Corre `rdl_pipeline.py` de tu página con esta misma tabla de tareas y compara la AUROC de test contra
la fila D (0.862) y contra la regla A. Usa los mismos cortes, la misma población y la misma métrica;
si no, la comparación no vale.
